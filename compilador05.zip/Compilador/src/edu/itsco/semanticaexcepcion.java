package edu.itsco;

public class semanticaexcepcion extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final int variables_no_declaradas=10;
	
	public static final int variables_duplicadas=20;
	
	public static final int variables_no_inicializadas=30;
	
	public static final int tipos_no_coinciden=40;
	
	public semanticaexcepcion()
	{
		super();
		
		
	}
	
	public semanticaexcepcion (String variable, int tipoexcepcion) {
		super(getMensaje(variable,tipoexcepcion));
	}

	private static  String getMensaje(String variable, int tipoexcepcion)
	{
		String msg=null;
		switch(tipoexcepcion)
		{
		case variables_no_declaradas:
			msg="la variable\""+variable+"\"no ha sido declarada;";
			break;
			
		case variables_duplicadas:
			msg="la variable\""+variable+"\"ya ha sido declarada;";
			break;
			
		case variables_no_inicializadas:
			msg="la variable\""+variable+"\"no ha sido inicializada;";
		    break;
		    
		case tipos_no_coinciden:
			msg="El tipo de datono coincide con el tipo de la variable"+variable+"\".";
			break;
		}
		
		return msg;
	}
	
}
