package edu.itsco;


public class ExcepcionSemantica extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public enum Tipo{
		VARIABLE_NO_DEFINIDA,VARIABLE_NO_INICIALIZADA,
		VARIABLE_DUPLICADA,TIPO_NO_COINCIDEN
	}
	public ExcepcionSemantica()
	{
		super();
	}
	
	public ExcepcionSemantica (Variable variable , Tipo tipo)
	{
		super(obtenerMensaje(variable,tipo));
	}
	
	private static String obtenerMensaje(Variable variable,Tipo tipo) {
		String mensaje= null;
		switch (tipo) {
		
		case VARIABLE_DUPLICADA:
			mensaje="la variable"+variable.getId()
+"Ya esta declarada";
			break;
			
		case VARIABLE_NO_DEFINIDA:
			mensaje="la variable"+variable.getId()
+"no esta declarada";
			break;
			
		case VARIABLE_NO_INICIALIZADA:
			mensaje="la variable"+variable.getId()
+"no se ha inicializado";
			break;
			
		case TIPO_NO_COINCIDEN:
			mensaje="los tipos de datos no coinciden con lavariable"+variable.getId();
			break;
			
		}
		
		
		return mensaje;
	}
	
}
