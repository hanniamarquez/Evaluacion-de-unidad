package edu.itsco;

public class MiExcepcion extends Exception {
	public static final int DIVISOR_0 = 10;
	public static final int DIVIDENDO_0 = 20;
	
	public MiExcepcion (int tipoExcepcion) {
		super(obtenerMensaje(tipoExcepcion));
		}
	
	private static String obtenerMensaje(int tipoExcepcion)
	{
		String mensaje = null;
		switch(tipoExcepcion) {
		case DIVISOR_0:
			mensaje = "EL DIVISOR NO PUEDE SER 0";
			break;
			
		case DIVIDENDO_0:
			mensaje = "EL DIVISOR NO PUEDE SER 0";
			break;
		}
		return mensaje;
	}
	

}
