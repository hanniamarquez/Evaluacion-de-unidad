package edu.itsco;

import java.util.ArrayList;
import java.util.List;

public class UtilizandoArrayList {
	
	public static void main(String[] args) {
		ArrayList<String> nombres = new ArrayList<>();
		
		//agregar elementos
		nombres.add("Hannia");
		nombres.add(0,"Hanni");
		
		//recorrer ArrayList
		
		for(int i=0;i<nombres.size();i++) {
			System.out.println(nombres.get(i));
		}
		
		
		/*List<Celular> listaDeCelulares  = new ArrayList<>();
		listaDeCelulares.add(new Celular());
		Celular galaxy = new Celular("Samsung","S21 ultra","Android 11",20000.00);
		listaDeCelulares.add(galaxy);
		
		
		System.out.println("imprimiendo con foreach");
		for(Celular celular: listaDeCelulares) {
			System.out.println(celular);}*/
			
		
			}
}
