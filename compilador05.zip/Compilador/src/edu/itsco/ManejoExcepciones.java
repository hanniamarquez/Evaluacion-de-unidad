package edu.itsco;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ManejoExcepciones {
	
	public static void main(String[] args) {
		int numero;
		int numero2;
		Scanner entrada = new Scanner (System.in);
		Calculadora calc = new Calculadora();
		try {
		System.out.println("ingresa un numero");
		numero = entrada.nextInt();
		//System.out.println("El numero que capturaste es:"+numero);
		System.out.println("Ingresa otro numero");
		numero2 = entrada.nextInt();
		double resultado = calc.division(numero, numero2);
		System.out.println("el resultado es:"+ resultado);
		}catch(InputMismatchException ime) {
			System.err.println("Escribe elnumero en decimal");
		}catch (MiExcepcion me) {
			System.err.println(me.getMessage());
		}catch (Exception e) {System.err.println(e.getMessage());}

}
	}
