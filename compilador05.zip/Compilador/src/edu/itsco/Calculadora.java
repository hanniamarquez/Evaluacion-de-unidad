package edu.itsco;

public class Calculadora {

public double sumar(double n1, double n2) {
	return n1+n2;
}

public double restar(double n1, double n2) {
	return n1-n2;
}

public double multiplicar(double n1, double n2) {
	return n1*n2;
}
	
public double division(double n1, double n2) 
		throws MiExcepcion {
	          if (n1==0) {
		throw new MiExcepcion(MiExcepcion.DIVIDENDO_0);
	}
	if(n2==0) {
		//System.out.println("n2 no puede ser 0");
		//throw new Exception("N2 no debe ser 0");
		throw new MiExcepcion(MiExcepcion.DIVISOR_0);
		
	}
	return n1/n2;
}
	



}
